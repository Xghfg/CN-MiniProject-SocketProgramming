import socket
import ssl
import threading

# Define the host and port for the server
host = '127.0.0.1'
port = 12000

# Function to handle user input for choosing an operation
def get_user_input():
    print("Select operation:")
    print("(1) Reverse the string")
    print("(2) Capitalize the entire string")
    print("(3) Decapitalize the entire string")
    print("(4) Display initials of the person (assuming the string is a name)")

    operation_choice = input("Enter your choice (1-4): ")
    return int(operation_choice)

# Function to interact with the server
def communicate_with_server():
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE

    while True:
        # Create socket and wrap it with SSL encryption
        with socket.create_connection((host, port)) as sock:
            with context.wrap_socket(sock, server_hostname=host) as secure_socket:
                # Ask the user to input a string to send to the server
                message_to_send = input("Enter a string (or 'exit' to quit): ")

                # If user enters 'exit', break the loop and exit the client
                if message_to_send.lower() == 'exit':
                    print("Exiting the client.")
                    break

                # Send the string to the server
                secure_socket.sendall(message_to_send.encode())

                # Get the user's operation choice
                operation_choice = get_user_input()

                # Send the operation choice to the server
                secure_socket.sendall(str(operation_choice).encode())

                # Receive and print the result from the server
                result = secure_socket.recv(1024).decode()
                print(f"Result from server: {result}")

        print("\n--- End of this request ---\n")

# Main function to start communication in a separate thread
def main():
    client_thread = threading.Thread(target=communicate_with_server)
    client_thread.start()
    client_thread.join()

if __name__ == "__main__":
    main()
