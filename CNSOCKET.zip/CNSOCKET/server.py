import socket
import ssl
import threading

# Function to perform different operations based on the user's choice
def perform_operation(operation, data):
    if operation == 1:
        return data[::-1]  # Reverse the string
    elif operation == 2:
        return data.upper()  # Capitalize the entire string
    elif operation == 3:
        return data.lower()  # Decapitalize the entire string
    elif operation == 4:
        # Display initials of each name in the string (assumed to be a name)
        names = data.split()
        initials = ''.join([name[0].upper() for name in names])
        return initials
    else:
        return "Invalid operation"  # In case the operation choice is invalid

# Function to handle each client connection
def handle_client(client_socket, addr, context):
    with context.wrap_socket(client_socket, server_side=True) as secure_socket:
        print(f"Got connection from {addr}")

        # Receive the string data from the client
        data = secure_socket.recv(1024).decode()
        print(f"Received from the client: {data}")

        # Receive the operation choice from the client
        operation_choice = int(secure_socket.recv(1024).decode())

        # Perform the operation and send the result back to the client
        result = perform_operation(operation_choice, data)
        secure_socket.sendall(result.encode())

# Main server function to set up the socket and handle incoming connections
def main():
    host = '127.0.0.1'  # Localhost for local communication
    port = 12000  # Port to listen on

    # Set up SSL context to ensure secure communication
    context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    context.load_cert_chain(certfile="cert.pem", keyfile="private_key.pem")  # Load SSL certificate and private key

    # Set up the server socket to listen for incoming connections
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((host, port))
        server_socket.listen(5)
        print(f"Server listening on {host}:{port}")

        # Continuously accept and handle clients
        while True:
            client_socket, addr = server_socket.accept()  # Accept incoming connection
            # Handle each client in a separate thread to allow multiple clients simultaneously
            client_thread = threading.Thread(target=handle_client, args=(client_socket, addr, context))
            client_thread.start()

if __name__ == "__main__":  # Make sure the server only runs when this script is executed directly
    main()
